<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'iEncry')); ?></title>
    <link rel="shortcut icon" href="#">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link rel="stylesheet"http://code.ionicframework.com/1.3.3/css/ionic.min.css">

    <link rel="stylesheet"http://code.ionicframework.com/1.3.3/css/ionic.min.css">

    

    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/jqvmap/jqvmap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/dist/css/dropzone.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/daterangepicker/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/summernote/summernote-bs4.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/sweetalert2/sweetalert2.min.css')); ?>">

    <?php echo $__env->yieldContent('css'); ?>
    <style>
        .logo-wrapper{
            height: 7rem;
            border: dashed 1.5px blue;
            background-repeat: no-repeat;
            background-size: cover;
            width: 100% !important;
            cursor: pointer;
            display: inline-flex;
            background-image: url(<?php echo e(asset('/virus.png')); ?>);
        }

        .logo-input{
            opacity: 0;
            height: 7rem;
            cursor: pointer;
            padding: 0px;
            width: 103px;
        }
        .img-wrapper{
            height: 7rem;
            width: 115px !important;
            cursor: pointer;
            margin-top: -3px;
            margin-left: -104px;
        }

    </style>
</head>
<body class="hold-transition sidebar-mini">

<div class="wrapper">

    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        

        <!-- SEARCH FORM -->
        

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">

          
          <!-- Notifications Dropdown Menu -->
          

          <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
              <i style="color:red;" class="fas fa-power-off"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
               Logout <i style="float: right; padding-top:5px;" class="fas fa-sign-out-alt"></i>
              </a>
            </div>
          </li>
          
        </ul>
      </nav>
<?php /**PATH D:\projects\trazenet\resources\views/layouts/backend/header.blade.php ENDPATH**/ ?>