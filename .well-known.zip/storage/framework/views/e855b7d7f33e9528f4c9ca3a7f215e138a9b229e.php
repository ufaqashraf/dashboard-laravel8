
<style>
    .loading-spin {
        position: absolute;
        z-index: 9999;
        left: 21%;
        top: 37%;
        display: none;
    }

    .loading-spin img {
        height: 100px;
        width: 100px;
    }

</style>
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 1589.56px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div id="disableDiv" style="padding: 5px;
                                background-color: white;
                                border: 1px solid #ddd;
                                box-shadow: 1px 1px #ddd;
                                border-radius: 5px;display: inline-flex;">
                        <button onclick="createTicket()" type="button" style="padding: 10px;" class="btn btn-primary">
                            <i style="margin-right: 5px;font-size: 25px;margin-left: 5px;" class="fa fa-plus"
                                style="margin-right: 5px;"></i>
                        </button>
                        <p style="margin-left: 5px;
                                font-weight: 700;
                                margin-bottom: 0px;">Create Ticket
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="loading-spin" id="spin">
                        <img src="<?php echo e(asset('/loading.gif')); ?>" alt="">
                    </div>
                    <div id="ticketForm" class="card" style="display: none;width: 50% !important;position: relative;">
                        <div class="card-header" style="background: #007bff">
                            <h3 class="card-title" style="color: #fff">Ticket Info</h3>
                            <button type="button" onclick="closeForm()" class="close" aria-label="Close">
                                <span style="color: #fff" aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="card-body">
                            <form id="ticket-add" class="row">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="form-group col-md-12">
                                        <label class="mr-sm-2" for="inlineFormCustomSelect">Ticket Id</label>
                                        <input readonly id="ticket_id" name="ticket_id" type="text" class="form-control" placeholder="Enter ticket id" />
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label class="mr-sm-2" for="inlineFormCustomSelect">Your Query</label>
                                        <textarea name="user_query" type="text" class="form-control" placeholder="Enter your query"></textarea>
                                    </div>
                                    <div class="form-group" style="width: 100%">
                                        <button type="submit" style="width: 100%" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div id="ticketEditForm" class="card" style="display: none;width: 50% !important;position:relative;">
                        <div class="card-header" style="background: #28a745">
                            <h3 class="card-title" style="color: #fff">Update Ticket</h3>
                            <button type="button" onclick="closeForm()" class="close" aria-label="Close">
                                <span style="color: #fff" aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="card-body">
                            <form id="ticket-edit" class="row">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="form-group col-md-12">
                                        <label class="mr-sm-2" for="inlineFormCustomSelect">Ticket Id</label>
                                        <input readonly id="e_ticket_id" name="ticket_id" type="text" class="form-control" placeholder="Enter ticket id" />
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label class="mr-sm-2" for="inlineFormCustomSelect">Your Query</label>
                                        <textarea id="e_query" name="user_query" type="text" class="form-control" placeholder="Enter your query"></textarea>
                                    </div>
                                    <input type="hidden" id="id" name="id">
                                    <div class="form-group" style="width: 100%">
                                        <button type="submit" style="width: 100%;" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php if($data->type == 'super_admin'): ?>
                    <div id="ticket_table" class="card col-12">
                        <div class="card-header">
                            <h3 class="card-title">Incoming Ticket List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SI #</th>
                                        <th>Ticket ID</th>
                                        <th>Username</th>
                                        <th>User Query</th>
                                        <th>Status</th>
                                        <th>Communication</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $tickets->where('status','Pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($ticket->ticket_id); ?></td>
                                            <td><?php echo e($ticket->get_user->f_name); ?></td>
                                            <td><?php echo e(Str::Limit($ticket->query,100,'...')); ?></td>
                                            <td>
                                                <span style="cursor: pointer;"
                                                    onclick="changeStatus(<?php echo e($ticket->id); ?>)"
                                                    class="badge badge-danger">Pending</span>
                                                <span style="cursor: pointer;"
                                                    onclick="changeStatus(<?php echo e($ticket->id); ?>,'reject')"
                                                    class="badge badge-dark">Reject</span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/messenger')); ?>" class="badge badge-primary">Chat With User</a>
                                                <a href="<?php echo e(url('/mail-inbox')); ?>" class="badge badge-success">Mail</a>
                                            </td>
                                            <td>
                                                <button onclick="viewTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-eye"></i>
                                                </button>

                                                <button onclick="editTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <button onclick="deleteTicket(`<?php echo e($ticket->id); ?>`)"
                                                    class="btn btn-danger btn-xs">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                    <div id="ticket_table" class="card col-12">
                        <div class="card-header">
                            <h3 class="card-title">Ticket Solved List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example3" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SI #</th>
                                        <th>Ticket ID</th>
                                        <th>Username</th>
                                        <th>User Query</th>
                                        <th>Status</th>
                                        <th>Communication</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $tickets->where('status','Solved'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($ticket->ticket_id); ?></td>
                                            <td><?php echo e($ticket->get_user->f_name); ?></td>
                                            <td><?php echo e(Str::Limit($ticket->query,100,'...')); ?></td>
                                            <td>
                                                <span class="badge badge-success">Solved</span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/messenger')); ?>" class="badge badge-primary">Chat With User</a>
                                                <a href="<?php echo e(url('/mail-inbox')); ?>" class="badge badge-success">Mail</a>
                                            </td>
                                            <td>
                                                <button onclick="viewTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-eye"></i>
                                                </button>

                                                <button onclick="editTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <button onclick="deleteTicket(`<?php echo e($ticket->id); ?>`)"
                                                    class="btn btn-danger btn-xs">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php else: ?> 
                    <div id="ticket_table" class="card col-12">
                        <div class="card-header">
                            <h3 class="card-title">Ticket Solved List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example5" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SI #</th>
                                        <th>Ticket ID</th>
                                        <th>User Query</th>
                                        <th>Status</th>
                                        <th>Communication</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $tickets->where('user_id',$data->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($ticket->ticket_id); ?></td>
                                            <td><?php echo e(Str::Limit($ticket->query,100,'...')); ?></td>
                                            <td>
                                                <span class="badge badge-success"><?php echo e($ticket->status); ?></span>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(url('/messenger')); ?>" class="badge badge-primary">Chat With Admin</a>
                                                
                                            </td>
                                            <td>
                                                <button onclick="viewTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-eye"></i>
                                                </button>

                                                <button onclick="editTicket(<?php echo e($ticket); ?>)"
                                                    class="btn btn-dark btn-xs">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <button onclick="deleteTicket(`<?php echo e($ticket->id); ?>`)"
                                                    class="btn btn-danger btn-xs">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

    <div class="modal fade" id="view_ticket" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="title" class="modal-title" id="exampleModalLabel" style="text-transform: capitalize;"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group col-md-12">
                        <label class="mr-sm-2" for="inlineFormCustomSelect">Ticket Id</label>
                        <input readonly id="v_ticket_id" name="ticket_id" type="text" class="form-control" placeholder="Enter ticket id" />
                    </div>
                    <div class="form-group col-md-12">
                        <label class="mr-sm-2" for="inlineFormCustomSelect">User Query</label>
                        <textarea disabled id="v_query" name="query" type="text" class="form-control" placeholder="Enter your query"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="auth" value="<?php echo e($data->id); ?>">
<?php $__env->startSection('js'); ?>

    <script type="text/javascript">
        $(function() {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

        $(function() {
            $("#example3").DataTable();
            $('#example4').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

        $(function() {
            $("#example5").DataTable();
            $('#example6').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

    </script>

    <script>
        
        window.onload =(()=>{
            var data = Math.floor(100000 + Math.random() * 900000)+$("#auth").val();
            $("#ticket_id").val(data);
        });

        function viewTicket(ticket){
            $("#v_ticket_id").val(ticket.ticket_id);
            $("#v_query").text(ticket.query);
            $("#title").text("View "+ticket.get_user.f_name+" Ticket");
            $("#view_ticket").modal('show');
        }

        function createTicket() {
            $("#ticket_table").hide();
            $("#ticketForm").show();
            $("#ticketEditForm").hide();
        }

        function closeForm() {
            $("#ticket_table").show();
            $("#ticketForm").hide();
            $("#ticketEditForm").hide();
        }

        function editTicket(ticket) {
            $("#e_ticket_id").val(ticket.ticket_id);
            $("#id").val(ticket.id);
            $("#e_query").val(ticket.query);
            $("#ticket_table").hide();
            $("#ticketForm").hide();
            $("#ticketEditForm").show();
        }

        $(document).ready(function() {
            $('#ticket-add').validate({
                rules: {
                    ticket_id: {
                        required: true
                    },
                    user_query: {
                        required: true
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                submitHandler: function(form) {
                    $("#spin").show();
                    $("#ticketForm").css({
                        'opacity': '.4'
                    });
                    $.ajax({
                        url: "<?php echo e(route('ticket.store')); ?>",
                        method: "POST",
                        data: new FormData(document.getElementById("ticket-add")),
                        enctype: 'multipart/form-data',
                        dataType: 'JSON',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(res) {
                            $("#spin").hide();
                            window.location.reload();
                            Toast.fire({
                                title: 'Ticket create successfull'
                            })
                        },
                        error: function() {
                            $("#spin").hide();
                            Swal.fire({
                                title: 'Field required'
                            })
                        }
                    })
                }
            });

        });

        $(document).ready(function() {
            $('#ticket-edit').validate({
                rules: {
                    ticket_id: {
                        required: true
                    },
                    query: {
                        required: true
                    },
                },
                errorElement: 'span',
                errorPlacement: function(error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function(element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function(element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                },
                submitHandler: function(form) {
                    $("#spin").show();
                    $("#ticketEditForm").css({
                        'opacity': '.4'
                    });
                    $.ajax({
                        url: "<?php echo e(route('ticket.update')); ?>",
                        method: "POST",
                        data: new FormData(document.getElementById("ticket-edit")),
                        enctype: 'multipart/form-data',
                        dataType: 'JSON',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(res) {
                            $("#spin").hide();
                            window.location.reload();
                            Toast.fire({
                                title: 'Ticket update successfull'
                            })
                        },
                        error: function() {
                            $("#spin").hide();
                            Swal.fire({
                                title: 'Field required'
                            })
                        }
                    })
                }
            });

        });

        function deleteTicket(id) {
            $.ajax({
                url: "<?php echo e(route('ticket.delete')); ?>",
                method: "POST",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id': id
                },
                success: function(res) {
                    window.location.reload();
                    Toast.fire({
                        title: 'Ticket delete successfull.'
                    })
                },
                error: function() {

                    Swal.fire({
                        title: 'Field required'
                    })
                }
            })
        }

        function changeStatus(id,val) {
            $.ajax({
                url: "<?php echo e(route('ticket.status')); ?>",
                method: "POST",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id': id,
                    'val': val
                },
                success: function(res) {
                    window.location.reload();
                    Toast.fire({
                        title: 'Ticket solved successfull.'
                    })
                },
                error: function() {
                    window.location.reload();
                    Swal.fire({
                        title: 'Ticket Not Solved'
                    })
                }
            })
        }


    </script>
    

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trazenet/public_html/resources/views/layouts/backend/ticket/ticket.blade.php ENDPATH**/ ?>