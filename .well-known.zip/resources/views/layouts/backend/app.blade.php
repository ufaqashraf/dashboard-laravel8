@include('layouts.backend.header')
@include('layouts.backend.sidebar')



@yield('content')




@include('layouts.backend.footer')
