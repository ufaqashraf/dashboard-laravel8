

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboard overview</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">

        <div class="row col-md-12">
            <div class="card card-danger col-md-6">
              <div class="card-header">
                <h3 class="card-title">Payment Report</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="donutChart" style="height:230px; min-height:230px"></canvas>
              </div>
            </div>
            <div class="card card-danger col-md-6">
                <div class="card-header">
                  <h3 class="card-title">User Registered Overview</h3>
  
                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                  </div>
                </div>
                <div class="card-body">
                  <canvas id="pieChart" style="height:230px; min-height:230px"></canvas>
                </div>
            </div>
            <div class="card col-md-6">
              <div class="row">
                <div class="col-lg-6 col-6">
                  <!-- small box -->
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h3><?php echo e($orderToday); ?></h3>
      
                      <p>Daily Orders</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-bag"></i>
                    </div>
                    <a href="<?php echo e(route('order')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-6 col-6">
                  <!-- small box -->
                  <div class="small-box bg-success">
                    <div class="inner">
                      <h3><?php echo e($orderMonthly); ?></h3>
      
                      <p>Monthly Orders</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="<?php echo e(route('order')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-6 col-6">
                  <!-- small box -->
                  <div class="small-box bg-warning">
                    <div class="inner">
                      <h3><?php echo e($orderYearly); ?></h3>
      
                      <p>Yearly Orders</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(route('order')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-6 col-6">
                  <!-- small box -->
                  <div class="small-box bg-danger">
                    <div class="inner">
                      <h3><?php echo e($total); ?></h3>
      
                      <p>Total User</p>
                    </div>
                    <div class="icon">
                      <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="<?php echo e(url('all-user')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                  </div>
                </div>
                <!-- ./col -->
              </div>
            </div>
            <div class="card card-danger col-md-6">
              <div class="card-header">
                <h3 class="card-title">HelpDesk Report</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="barChart" style="height:230px; min-height:230px"></canvas>
              </div>
            </div>
      </div>

      <div class="row">
        <div class="col-md-12">
            <?php if($data->type == 'user'): ?>
            <div id="user_order_table" class="card col-12">
                <div class="card-header">
                    <h3 class="card-title">Order List Overview</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example3" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SI #</th>
                                <th>Date</th>
                                <th>Name</th>
                                <th>Package</th>
                                <th>Price</th>
                                <th>Duration</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 0;
                            ?>
                            <?php $__currentLoopData = $orders->where('user_id',$data->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $i++;
                                ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?></td>
                                    <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                    <td><?php echo e($order->package); ?></td>
                                    <td><?php echo e($order->price); ?></td>
                                    <td><?php echo e($order->duration); ?></td>
                                    <td>
                                        <button onclick="deleteOrder(<?php echo e($order->id); ?>)" class="btn btn-danger btn-xs">
                                            <i class="fa fa-trash"></i>    
                                        </button>    
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?> 
            <div id="all_order_table" class="card col-12">
                <div class="card-header">
                    <h3 class="card-title">Order List</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example3" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>SI #</th>
                                <th>Date</th>
                                <th>Name</th>
                                <th>Package</th>
                                <th>Price</th>
                                <th>Duration</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 0;
                            ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $i++;
                                ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?></td>
                                    <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                    <td><?php echo e($order->package); ?></td>
                                    <td><?php echo e($order->price); ?></td>
                                    <td><?php echo e($order->duration); ?></td>
                                    <td>
                                        <button onclick="deleteOrder(<?php echo e($order->id); ?>)" class="btn btn-danger btn-xs">
                                            <i class="fa fa-trash"></i>    
                                        </button>    
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    </section>
  </div>

<?php $__env->startSection('js'); ?>
<script>
$(function () {
    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieData ={
      labels: [
          'Daily'+' '+<?php echo e($daily); ?>,
          'Weekly'+' '+<?php echo e($week); ?>,
          'Monthly'+' '+<?php echo e($monthly); ?>,
          'Yearly'+' '+<?php echo e($yearly); ?>

            
      ],
      datasets: [
        {
          data: [
              <?php echo e($daily); ?>,
              <?php echo e($week); ?>,
              <?php echo e($monthly); ?>,
              <?php echo e($yearly); ?>

            ],
          backgroundColor : ['blue','dark', 'yellow', 'green'],
        }
      ]
    }
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    var pieChart = new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions      
    })

    //- DONUT CHART 

    var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          'Today'+' '+<?php echo e($orderToday); ?>,
          'This Month'+' '+<?php echo e($orderMonthly); ?>,
          'Last Month'+' '+<?php echo e($orderLastMonth); ?>, 
          'Year'+' '+<?php echo e($orderYearly); ?>

      ],
      datasets: [
        {
          data: [
              <?php echo e($orderToday); ?>,
              <?php echo e($orderMonthly); ?>,
              <?php echo e($orderLastMonth); ?>,
              <?php echo e($orderYearly); ?>

          ],
          backgroundColor : ['#555', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc'],
        }
      ]
    }
    var donutOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    var donutChart = new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions      
    })
    

    //- BAR CHART -
    //-------------
    var areaChartData = {
      // labels  : ['Receive', 'Solve', 'Delete'],
      datasets: [
        {
          label               : 'Receive'+' '+<?php echo e($receive); ?>,
          backgroundColor     : 'green',
          borderColor         : 'green',
          pointRadius         : false,
          width               :'100',
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(68,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php echo e($receive); ?>]
        },
        {
          label               : 'Solve'+' '+<?php echo e($solve); ?>,
          backgroundColor     : 'blue',
          borderColor         : 'blue',
          pointRadius         : false,
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : 'blue',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php echo e($solve); ?>]
        },
        {
          label               : 'Delete'+' '+<?php echo e($delete); ?>,
          backgroundColor     : 'yellow',
          borderColor         : 'yellow',
          pointRadius         : false,
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : 'yellow',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php echo e($delete); ?>]
        }
      ]
    }
    var barChartCanvas = $('#barChart').get(0).getContext('2d')
    var barChartData = jQuery.extend(true, {}, areaChartData)
    var temp0 = areaChartData.datasets[0]
    var temp1 = areaChartData.datasets[1]
    var temp2 = areaChartData.datasets[2]
    barChartData.datasets[0] = temp0
    barChartData.datasets[1] = temp1
    barChartData.datasets[2] = temp2

    var barChartOptions = {
      responsive              : true,
      maintainAspectRatio     : false,
      datasetFill             : false
    }

    var barChart = new Chart(barChartCanvas, {
      type: 'bar', 
      data: barChartData,
      options: barChartOptions
    })
  })
  </script>

  <script type="text/javascript">
      $(function() {
          $("#example3").DataTable();
          $('#example4').DataTable({
              "paging": true,
              "lengthChange": false,
              "searching": false,
              "ordering": true,
              "info": true,
              "autoWidth": false,
          });
      });

      $(function() {
          $("#example5").DataTable();
          $('#example6').DataTable({
              "paging": true,
              "lengthChange": false,
              "searching": false,
              "ordering": true,
              "info": true,
              "autoWidth": false,
          });
      });

  </script>

  <script>
      function deleteOrder(id){
          $.ajax({
              url: "<?php echo e(route('delete.order')); ?>",
              method: "POST",
              data: {
                  '_token': "<?php echo e(csrf_token()); ?>",
                  'id': id
              },
              success: function(res) {
                  window.location.reload();
                  Toast.fire({
                      icon: 'success',
                      title: 'Order delete successfull.'
                  })
              },
              error: function() {

                  Swal.fire({
                      icon: 'error',
                      title: 'Field required'
                  })
              }
          })
      }
  </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\trazenet\resources\views/layouts/backend/dashboard.blade.php ENDPATH**/ ?>