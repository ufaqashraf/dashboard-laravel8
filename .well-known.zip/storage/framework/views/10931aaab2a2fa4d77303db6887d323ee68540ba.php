

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 1589.56px;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <h1>Order Overview</h1>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <?php if($data->type == 'user'): ?>
                    <div id="user_order_table" class="card col-12">
                        <div class="card-header">
                            <h3 class="card-title">Order List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example3" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SI #</th>
                                        <th>Date</th>
                                        <th>Name</th>
                                        <th>Package</th>
                                        <th>Price</th>
                                        <th>Duration</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $orders->where('user_id',$data->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?></td>
                                            <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                            <td><?php echo e($order->package); ?></td>
                                            <td><?php echo e($order->price); ?></td>
                                            <td><?php echo e($order->duration); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php else: ?> 
                    <div id="all_order_table" class="card col-12">
                        <div class="card-header">
                            <h3 class="card-title">Order List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example3" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>SI #</th>
                                        <th>Date</th>
                                        <th>Name</th>
                                        <th>Package</th>
                                        <th>Price</th>
                                        <th>Duration</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 0;
                                    ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?></td>
                                            <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                            <td><?php echo e($order->package); ?></td>
                                            <td><?php echo e($order->price); ?></td>
                                            <td><?php echo e($order->duration); ?></td>
                                            <td>
                                                <button onclick="deleteOrder(<?php echo e($order->id); ?>)" class="btn btn-danger btn-xs">
                                                    <i class="fa fa-trash"></i>    
                                                </button>    
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

<?php $__env->startSection('js'); ?>

    <script type="text/javascript">
        $(function() {
            $("#example3").DataTable();
            $('#example4').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

        $(function() {
            $("#example5").DataTable();
            $('#example6').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

    </script>

    <script>
        function deleteOrder(id){
            $.ajax({
                url: "<?php echo e(route('delete.order')); ?>",
                method: "POST",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id': id
                },
                success: function(res) {
                    window.location.reload();
                    Toast.fire({
                        icon: 'success',
                        title: 'Order delete successfull.'
                    })
                },
                error: function() {

                    Swal.fire({
                        icon: 'error',
                        title: 'Field required'
                    })
                }
            })
        }
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trazenet/public_html/resources/views/layouts/backend/order/order.blade.php ENDPATH**/ ?>