
<style>
    .canvasjs-chart-credit {
        display: none !important;
    }

</style>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Dashboard overview</h1>
                    </div>
                </div>
            </div>
        </section>

        <section class="content">
            <div class="row col-md-12">
                <?php if($data->type == 'super_admin'): ?>

                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Payment Report</h3>
                        </div>
                        <div class="card-body">
                            <div id="payContainer" style="height: 300px; width: 100%;"></div>
                            <button id="printPay">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">User Registered Overview</h3>
                        </div>
                        <div class="card-body">
                            <div id="pieChart" style="height: 300px; width: 100%;"></div>
                            <button id="printUser">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">HelpDesk Report</h3>
                        </div>
                        <div class="card-body">
                            <div id="helpDeskContainer" style="height: 275px; width: 100%;"></div>
                            <button id="printHelp">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Device Allocated</h3>
                        </div>
                        <div class="card-body">
                            <div id="deviceadminContainer" style="height:300px; width:100%"></div>
                            <button id="printadminDevice">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Ticket Raise</h3>
                        </div>
                        <div class="card-body">
                            <div id="ticketadminContainer" style="height:300px; width:100%"></div>
                            <button id="printadminTicket">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Rules Added</h3>
                        </div>
                        <div class="card-body">
                            <div id="rulesadminContainer" style="height:300px; width:100%"></div>
                            <button id="printadminRules">Print Chart</button>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Device Allocated</h3>
                        </div>
                        <div class="card-body">
                            <div id="deviceContainer" style="height:300px; width:100%"></div>
                            <button id="printDevice">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Ticket Raise</h3>
                        </div>
                        <div class="card-body">
                            <div id="ticketContainer" style="height:300px; width:100%"></div>
                            <button id="printTicket">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6">
                        <div class="card-header">
                            <h3 class="card-title">Total Rules Added</h3>
                        </div>
                        <div class="card-body">
                            <div id="rulesContainer" style="height:300px; width:100%"></div>
                            <button id="printRules">Print Chart</button>
                        </div>
                    </div>
                    <div class="card card-danger col-md-6" id="dasdfas">
                        <div class="card-header">
                            <h3 class="card-title">Alert & Signals</h3>
                        </div>
                        <div class="card-body" id="printddd">
                            <div id="chartContainer" style="height: 275px; width: 100%;"></div>
                            <button id="printAlert">Print Chart</button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if($data->type == 'user'): ?>
                        <div id="user_order_table" class="card col-12">
                            <div class="card-header">
                                <h3 class="card-title">Order List Overview</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example3" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>SI #</th>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Package</th>
                                            <th>Price</th>
                                            <th>Duration</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 0;
                                        ?>
                                        <?php $__currentLoopData = $orders->where('user_id', $data->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $i++;
                                            ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?>

                                                </td>
                                                <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                                <td><?php echo e($order->package); ?></td>
                                                <td><?php echo e($order->price); ?></td>
                                                <td><?php echo e($order->duration); ?></td>
                                                <td>
                                                    <button onclick="deleteOrder(<?php echo e($order->id); ?>)"
                                                        class="btn btn-danger btn-xs">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php else: ?>
                        <div id="all_order_table" class="card col-12">
                            <div class="card-header">
                                <h3 class="card-title">Order List</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example3" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>SI #</th>
                                            <th>Date</th>
                                            <th>Name</th>
                                            <th>Package</th>
                                            <th>Price</th>
                                            <th>Duration</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 0;
                                        ?>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $i++;
                                            ?>
                                            <tr>
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e(Carbon\Carbon::parse($order->created_at)->isoFormat('MMM Do YYYY, h:mm A')); ?>

                                                </td>
                                                <td><?php echo e(optional($order->get_user)->f_name); ?></td>
                                                <td><?php echo e($order->package); ?></td>
                                                <td><?php echo e($order->price); ?></td>
                                                <td><?php echo e($order->duration); ?></td>
                                                <td>
                                                    <button onclick="deleteOrder(<?php echo e($order->id); ?>)"
                                                        class="btn btn-danger btn-xs">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(function() {
            $("#example3").DataTable();
            $('#example4').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

        $(function() {
            $("#example5").DataTable();
            $('#example6').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

        function deleteOrder(id) {
            $.ajax({
                url: "<?php echo e(route('delete.order')); ?>",
                method: "POST",
                data: {
                    '_token': "<?php echo e(csrf_token()); ?>",
                    'id': id
                },
                success: function(res) {
                    window.location.reload();
                    Toast.fire({
                        icon: 'success',
                        title: 'Order delete successfull.'
                    })
                },
                error: function() {

                    Swal.fire({
                        icon: 'error',
                        title: 'Field required'
                    })
                }
            })
        }

    </script>

    <?php if($data->type == 'super_admin'): ?>
        <script type="text/javascript">
            // user registered chart

            window.onload = function() {
                var userchart = new CanvasJS.Chart("pieChart", {
                    title: {
                        text: "User Registered Overview"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($daily); ?>,
                                indexLabel: "Today" + " " + <?php echo e($daily); ?>

                            },
                            {
                                y: <?php echo e($week); ?>,
                                indexLabel: "This Week" + " " + <?php echo e($week); ?>

                            },
                            {
                                y: <?php echo e($monthly); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($monthly); ?>

                            },
                            {
                                y: <?php echo e($yearly); ?>,
                                indexLabel: "This Year" + " " + <?php echo e($yearly); ?>

                            },
                            {
                                y: <?php echo e($lastyear); ?>,
                                indexLabel: "Last Year" + " " + <?php echo e($lastyear); ?>

                            }
                        ]
                    }]
                });
                userchart.render();
                document.getElementById("printUser").addEventListener("click", function() {
                    userchart.print();
                });


                //payment chart

                var paymentchart = new CanvasJS.Chart("payContainer", {
                    title: {
                        text: "Payment Report"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($orderToday); ?>,
                                indexLabel: "Today" + " " + <?php echo e($orderToday); ?>

                            },
                            {
                                y: <?php echo e($orderMonthly); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($orderMonthly); ?>

                            },
                            {
                                y: <?php echo e($orderLastMonth); ?>,
                                indexLabel: "Last Month" + " " + <?php echo e($orderLastMonth); ?>

                            },
                            {
                                y: <?php echo e($orderYearly); ?>,
                                indexLabel: "Yearly" + " " + <?php echo e($orderYearly); ?>

                            }
                        ]
                    }]
                });
                paymentchart.render();
                document.getElementById("printPay").addEventListener("click", function() {
                    paymentchart.print();
                });
                
                 //device chart

                    var deviceadminchart = new CanvasJS.Chart("deviceadminContainer", {
                        title: {
                            text: "Total Device Allocated",
                            fontFamily: "Impact",
                            fontWeight: "normal"
                        },
    
                        legend: {
                            verticalAlign: "bottom",
                            horizontalAlign: "center"
                        },
                        data: [{
                            //startAngle: 45,
                            indexLabelFontSize: 20,
                            indexLabelFontFamily: "Garamond",
                            indexLabelFontColor: "darkgrey",
                            indexLabelLineColor: "darkgrey",
                            indexLabelPlacement: "outside",
                            type: "doughnut",
                            showInLegend: true,
                            dataPoints: [{
                                    y: <?php echo e($deviceadminToday); ?>,
                                    legendText: <?php echo e($deviceadminToday); ?>,
                                    indexLabel: "Today" + ' ' + <?php echo e($deviceadminToday); ?>

                                },
                                {
                                    y: <?php echo e($deviceadminThisMonth); ?>,
                                    legendText: <?php echo e($deviceadminThisMonth); ?>,
                                    indexLabel: "This Month" + ' ' + <?php echo e($deviceadminThisMonth); ?>

                                },
                                {
                                    y: <?php echo e($deviceadminLastMonth); ?>,
                                    legendText: <?php echo e($deviceadminLastMonth); ?>,
                                    indexLabel: "Last Month" + ' ' + <?php echo e($deviceadminLastMonth); ?>

                                },
                                {
                                    y: <?php echo e($deviceadminYearly); ?>,
                                    legendText: <?php echo e($deviceadminYearly); ?>,
                                    indexLabel: "Year" + ' ' + <?php echo e($deviceadminYearly); ?>

                                }
                            ]
                        }]
                    });
    
                    deviceadminchart.render();
                    document.getElementById("printadminDevice").addEventListener("click", function() {
                        deviceadminchart.print();
                    });


                //ticket chart

                var ticketadminchart = new CanvasJS.Chart("ticketadminContainer", {
                    title: {
                        text: "Total Ticket Raise"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($ticketadminToday); ?>,
                                indexLabel: "Today" + " " + <?php echo e($ticketadminToday); ?>

                            },
                            {
                                y: <?php echo e($ticketadminThisMonth); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($ticketadminThisMonth); ?>

                            },
                            {
                                y: <?php echo e($ticketadminLastMonth); ?>,
                                indexLabel: "Last Month" + " " + <?php echo e($ticketadminLastMonth); ?>

                            },
                            {
                                y: <?php echo e($ticketadminYearly); ?>,
                                indexLabel: "Yearly" + " " + <?php echo e($ticketadminYearly); ?>

                            }
                        ]
                    }]
                });

                ticketadminchart.render();
                document.getElementById("printadminTicket").addEventListener("click", function() {
                    ticketadminchart.print();
                });
                
                
                //rules chart..
                var rulesadminchart = new CanvasJS.Chart("rulesadminContainer", {
                    title: {
                        text: "Total Rules Added"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($rulesadminToday); ?>,
                                indexLabel: "Today" + " " + <?php echo e($rulesadminToday); ?>

                            },
                            {
                                y: <?php echo e($rulesadminThisMonth); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($rulesadminThisMonth); ?>

                            },
                            {
                                y: <?php echo e($rulesadminLastMonth); ?>,
                                indexLabel: "Last Month" + " " + <?php echo e($rulesadminLastMonth); ?>

                            },
                            {
                                y: <?php echo e($rulesadminYearly); ?>,
                                indexLabel: "Yearly" + " " + <?php echo e($rulesadminYearly); ?>

                            }
                        ]
                    }]
                });

                rulesadminchart.render();
                document.getElementById("printadminRules").addEventListener("click", function() {
                    rulesadminchart.print();
                });
                
                //help desk chart
                var helpDesk = new CanvasJS.Chart("helpDeskContainer", {
                    theme: "light2",
                    title: {
                        text: "HelpDesk Report"
                    },
                    data: [{
                        type: "column",
                        dataPoints: [{
                                label: "Receive"+" "+<?php echo e($receive); ?>,
                                y: <?php echo e($receive); ?>

                            },
                            {
                                label: "Solved"+" "+<?php echo e($solve); ?>,
                                y: <?php echo e($solve); ?>

                            },
                            {
                                label: "Delete"+" "+<?php echo e($delete); ?>,
                                y: <?php echo e($delete); ?>

                            }
                        ]
                    }]
                });

                helpDesk.render();
                document.getElementById("printHelp").addEventListener("click", function() {
                    helpDesk.print();
                });
                

            }

        </script>
        
    <?php endif; ?>

    <?php if($data->type == 'user'): ?>

        <script>
                window.onload = function() {
                     //device chart

                    var devicechart = new CanvasJS.Chart("deviceContainer", {
                        title: {
                            text: "Total Device Allocated",
                            fontFamily: "Impact",
                            fontWeight: "normal"
                        },
    
                        legend: {
                            verticalAlign: "bottom",
                            horizontalAlign: "center"
                        },
                        data: [{
                            //startAngle: 45,
                            indexLabelFontSize: 20,
                            indexLabelFontFamily: "Garamond",
                            indexLabelFontColor: "darkgrey",
                            indexLabelLineColor: "darkgrey",
                            indexLabelPlacement: "outside",
                            type: "doughnut",
                            showInLegend: true,
                            dataPoints: [{
                                    y: <?php echo e($deviceToday); ?>,
                                    legendText: <?php echo e($deviceToday); ?>,
                                    indexLabel: "Today" + ' ' + <?php echo e($deviceToday); ?>

                                },
                                {
                                    y: <?php echo e($deviceThisMonth); ?>,
                                    legendText: <?php echo e($deviceThisMonth); ?>,
                                    indexLabel: "This Month" + ' ' + <?php echo e($deviceThisMonth); ?>

                                },
                                {
                                    y: <?php echo e($deviceLastMonth); ?>,
                                    legendText: <?php echo e($deviceLastMonth); ?>,
                                    indexLabel: "Last Month" + ' ' + <?php echo e($deviceLastMonth); ?>

                                },
                                {
                                    y: <?php echo e($deviceYearly); ?>,
                                    legendText: <?php echo e($deviceYearly); ?>,
                                    indexLabel: "Year" + ' ' + <?php echo e($deviceYearly); ?>

                                }
                            ]
                        }]
                    });
    
                    devicechart.render();
                    document.getElementById("printDevice").addEventListener("click", function() {
                        devicechart.print();
                    });
                    
                    //alert signals chart
                    
                    var chart = new CanvasJS.Chart("chartContainer", {
                        theme: "light2",
                        title: {
                            text: "Alert & Signals"
                        },
                        data: [{
                            type: "column",
                            dataPoints: [{
                                    label: "Today",
                                    y: 10
                                },
                                {
                                    label: "This Month",
                                    y: 15
                                },
                                {
                                    label: "Last Month",
                                    y: 25
                                },
                                {
                                    label: "Year",
                                    y: 30
                                }
                            ]
                        }]
                    });

                    chart.render();
                    document.getElementById("printAlert").addEventListener("click", function() {
                        chart.print();
                    });
                    
                    
                //ticket chart

                var ticketchart = new CanvasJS.Chart("ticketContainer", {
                    title: {
                        text: "Total Ticket Raise"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($ticketToday); ?>,
                                indexLabel: "Today" + " " + <?php echo e($ticketToday); ?>

                            },
                            {
                                y: <?php echo e($ticketThisMonth); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($ticketThisMonth); ?>

                            },
                            {
                                y: <?php echo e($ticketLastMonth); ?>,
                                indexLabel: "Last Month" + " " + <?php echo e($ticketLastMonth); ?>

                            },
                            {
                                y: <?php echo e($ticketYearly); ?>,
                                indexLabel: "Yearly" + " " + <?php echo e($ticketYearly); ?>

                            }
                        ]
                    }]
                });

                ticketchart.render();
                document.getElementById("printTicket").addEventListener("click", function() {
                    ticketchart.print();
                });
                
                
                //rules chart..
                var ruleschart = new CanvasJS.Chart("rulesContainer", {
                    title: {
                        text: "Total Rules Added"
                    },
                    legend: {
                        maxWidth: 350,
                        itemWidth: 120
                    },
                    data: [{
                        type: "pie",
                        showInLegend: true,
                        legendText: "{indexLabel}",
                        dataPoints: [{
                                y: <?php echo e($rulesToday); ?>,
                                indexLabel: "Today" + " " + <?php echo e($rulesToday); ?>

                            },
                            {
                                y: <?php echo e($rulesThisMonth); ?>,
                                indexLabel: "This Month" + " " + <?php echo e($rulesThisMonth); ?>

                            },
                            {
                                y: <?php echo e($rulesLastMonth); ?>,
                                indexLabel: "Last Month" + " " + <?php echo e($rulesLastMonth); ?>

                            },
                            {
                                y: <?php echo e($rulesYearly); ?>,
                                indexLabel: "Yearly" + " " + <?php echo e($rulesYearly); ?>

                            }
                        ]
                    }]
                });

                ruleschart.render();
                document.getElementById("printRules").addEventListener("click", function() {
                    ruleschart.print();
                });
            }

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ideatechsol/public_html/trazenet/resources/views/layouts/backend/dashboard.blade.php ENDPATH**/ ?>