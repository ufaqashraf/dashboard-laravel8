<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <h3><?php echo e($user->name); ?></h3>
        <p>Reset Password Link</p>

        <a href="<?php echo e(route('update.password.view')); ?>">
            Click<?php echo e(route('update.password.view')); ?>

        </a>
    </div>
</body>
</html>
<?php /**PATH /home/trazenet/public_html/resources/views/layouts/Mail/reset-pass-email-verify.blade.php ENDPATH**/ ?>