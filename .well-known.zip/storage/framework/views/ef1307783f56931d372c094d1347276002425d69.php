

<?php $__env->startSection('content'); ?>
<style>
    .nav-link-color {
        color: #000 !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1157.69px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Message Box</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Message Box</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <a href="<?php echo e(route('compose.index')); ?>" class="btn btn-primary btn-block mb-3">Compose</a>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Folders</h3>

                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <ul class="nav nav-pills flex-column">
                            <li class="nav-item">
                                <a href="<?php echo e(route('mail.inbox')); ?>" class="nav-link nav-link-color">
                                    <i class="far fa-envelope"></i> Sent
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('draft.index')); ?>" class="nav-link nav-link-color">
                                    <i class="far fa-file-alt"></i> Drafts
                                    <span
                                        class="badge bg-primary float-right"><?php echo e($mails->where('status','draft')->count()); ?></span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('trash')); ?>" class="nav-link nav-link-color">
                                    <i class="far fa-trash-alt"></i> Trash
                                    <span
                                        class="badge bg-danger float-right"><?php echo e($mails->where('status','trash')->count()); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.card-body -->
                </div>
            </div>
            <!-- /.col -->
            <?php echo $__env->yieldContent('mail_content'); ?>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/trazenet/public_html/resources/views/layouts/backend/mail/inbox.blade.php ENDPATH**/ ?>