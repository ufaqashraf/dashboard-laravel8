

<?php $__env->startSection('mail_content'); ?>
<style>
    .nav-link-color {
        color: #000 !important;
    }
</style>
<div class="col-md-9">
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="card-header">
            <h3 class="card-title">Trash</h3>
            <div class="float-right">
              <div class="btn-group">
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-chevron-left"></i></button>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-chevron-right"></i></button>
              </div>
            </div>
          </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body p-0">
        <div class="table-responsive mailbox-messages">
          <table class="table table-hover table-striped">
            <tbody>
              <?php $__currentLoopData = $mails->where('status','trash'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(route('show.mail',$mail->id)); ?>"></a>
              <tr>
                <td>
                  <div class="icheck-primary">
                    <a href="<?php echo e(route('msg.destroy',$mail->id)); ?>" class="btn btn-default btn-sm"><i class="far fa-trash-alt"></i></a>
                  </div>
                </td>
                <td class="mailbox-star"><a href="#"><i class="fas fa-star text-warning"></i></a></td>
                <td class="mailbox-name"><a href="<?php echo e(route('show.mail',$mail->id)); ?>"><?php echo e(Str::limit(optional($mail)->to,'10',' ')); ?></a></td>
                <td class="mailbox-subject"><?php echo e(Str::limit($mail->msg,50,'...')); ?>

                </td>
                <td class="mailbox-attachment"></td>
                <td class="mailbox-date"><?php echo e(\Carbon\Carbon::parse(optional($mail)->updated_at)->diffForHumans()); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <!-- /.table -->
        </div>
        <!-- /.mail-box-messages -->
      </div>
      <!-- /.card-body -->
      <div class="card-footer p-0">
        <div class="mailbox-controls">
          <div class="float-right">
            <div class="btn-group">
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-chevron-left"></i></button>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-chevron-right"></i></button>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.card -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.mail.inbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ideatechsol/public_html/trazenet/resources/views/layouts/backend/mail/trash.blade.php ENDPATH**/ ?>