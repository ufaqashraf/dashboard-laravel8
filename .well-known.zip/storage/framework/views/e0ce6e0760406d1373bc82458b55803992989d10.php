

<?php $__env->startSection('mail_content'); ?>
<style>
    .nav-link-color {
        color: #000 !important;
    }
</style>

<div class="col-md-9">
    <div class="card card-primary card-outline">
        <div class="card-header">
            <h3 class="card-title">Compose New Message</h3>

        </div>
        <!-- /.card-header -->
        <form id="compose">
            <?php echo csrf_field(); ?>
            <div class="card-body row">
                <div class="form-group col-sm-12">
                    
                    <select id="to" name="to" class="form-control">
                        <option value="" selected="selected" hidden>To:</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->email); ?>"><?php echo e($item->f_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-sm-12">
                    <input id="subject" value="<?php echo e(optional($msg)->subject); ?>" name="subject" class="form-control" placeholder="Subject:">
                </div>
                <div class="form-group col-sm-12">
                    <textarea id="msg" name="msg" class="form-control"><?php echo e(optional($msg)->msg); ?></textarea>
                </div>
            </div>
            <input type="hidden" id="msg_id" name="id" value="<?php echo e(optional($msg)->id); ?>">
            <div class="card-footer">
                <div class="float-right">
                    <button type="button" onclick="draft()" class="btn btn-default"><i class="fas fa-pencil-alt"></i>
                        Draft</button>
                    <button type="submit" class="btn btn-primary"><i class="far fa-envelope"></i> Send</button>
                </div>
                <button type="reset" onclick="discard()" class="btn btn-default"><i class="fas fa-times"></i>
                    Discard</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->startSection('js'); ?>

<script>
      function discard(){
        $("#to").val('');
        $("#subject").val('');
        $("#msg").val('');
      }

      function draft(){
        $.ajax({
            url:"<?php echo e(route('mail.draft')); ?>",
            method:"POST",
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                'to': $("#to").val(),
                'subject':$("#subject").val(),
                'msg':$("#msg").val()
            },
            success: function(response) {
                window.location.reload();
                Toast.fire({
                    icon:'success',
                    title:'Message saved successfull.'
                })
            },
            error: function() {
              Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'Wrong data entry.'
              })
            }
        })
      }

      $(document).ready(function () {
        $('#compose').validate({
            rules: {
                to: {
                    required: true
                },
                subject: {
                    required: true
                },
                msg: {
                    required: true
                }
            },
            errorElement: 'span',
            errorPlacement: function (error, element) {
                error.addClass('invalid-feedback');
                element.closest('.form-group').append(error);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).addClass('is-invalid');
            },
            unhighlight: function (element, errorClass, validClass) {
                $(element).removeClass('is-invalid');
            },
            submitHandler: function(form){
                $.ajax({
                    url: "<?php echo e(route('send.msg')); ?>",
                    method: "POST",
                    data: new FormData(document.getElementById("compose")),
                    enctype: 'multipart/form-data',
                    dataType: 'JSON',
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function(res) {
                        window.location.reload();
                        Toast.fire({
                            icon: 'success',
                            title: 'Message send successfull.'
                        })
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Field required'
                        })
                    }
                })
            }
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.mail.inbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ideatechsol/public_html/trazenet/resources/views/layouts/backend/mail/compose.blade.php ENDPATH**/ ?>